﻿using Microsoft.EntityFrameworkCore;
using Telegram.Bot;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Domain.OutPorts;
using Microsoft.Extensions.DependencyInjection;
using Storage.PostgresStorageAdapters;
using Storage.StorageAdapters;

public class Subscriber
{
    public long ChatId { get; set; }
    public string TaskTrackerLogin { get; set; }
    public string Password { get; set; }
    public string Username { get; set; }
    public DateTime SubscriptionDate { get; set; }
}

public class SubscriberDbContext : DbContext
{
    public DbSet<Subscriber> Subscribers { get; set; }

    public SubscriberDbContext(DbContextOptions<SubscriberDbContext> options) : base(options)
    {
        Database.EnsureCreated();
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Subscriber>().HasKey(u => u.ChatId);
    }
}

public class SubscriptionBot
{
    private readonly ITelegramBotClient _botClient;
    private readonly IMessageRepo _messageRepo;
    private readonly IUserRepo _userRepo;
    private readonly SubscriberDbContext _dbContext;
    private CancellationTokenSource _cts;

    private enum RegistrationState
    {
        None,
        AwaitingLogin,
        AwaitingPassword
    }

    private Dictionary<long, RegistrationState> _registrationStates = new();
    private Dictionary<long, string> _tempLogins = new();

    private const string WelcomeMessage = "Добро пожаловать! Введите ваш логин в системе TaskTracker:";
    private const string AskPasswordMessage = "Теперь введите ваш пароль в системе TaskTracker:";
    private const string RegistrationCompleteMessage = "Регистрация завершена! Вы подписаны на рассылку.";
    private const string GoodbyeMessage = "Вы отписались от рассылки";
    private const int timeout = 1;
    private const int timeout_err = 1;

    public SubscriptionBot(string botToken, IMessageRepo messageRepo, IUserRepo userRepo, SubscriberDbContext dbContext)
    {
        _botClient = new TelegramBotClient(botToken);
        _messageRepo = messageRepo;
        _userRepo = userRepo;
        _dbContext = dbContext;
    }

    public async Task StartAsync()
    {
        _cts = new CancellationTokenSource();

        var receiverOptions = new ReceiverOptions
        {
            AllowedUpdates = Array.Empty<UpdateType>()
        };

        _botClient.StartReceiving(
            updateHandler: HandleUpdateAsync,
            errorHandler: HandleErrorAsync,
            receiverOptions: receiverOptions,
            cancellationToken: _cts.Token
        );

        _ = Task.Run(StartBroadcasting, _cts.Token);

        Console.WriteLine("Бот запущен. Нажмите Ctrl+C для остановки.");
        await Task.Delay(-1, _cts.Token);
    }

    private async Task StartBroadcasting()
    {
        while (!_cts.IsCancellationRequested)
        {
            var users_habits = _messageRepo.GetUsersToNotify();
            List<Tuple<string, string>> user_message = [];
            try
            {
                int cnt = 0;
                foreach (var user in users_habits)
                {
                    var subscriber = await _dbContext.Subscribers
                        .FirstOrDefaultAsync(s => s.TaskTrackerLogin == user.UserName);

                    if (subscriber != null)
                    {
                        cnt++;
                        var message = $"Привет, {subscriber.Username}!\n" +
                                  $"Логин: {subscriber.TaskTrackerLogin}\n" +
                                  $"В ближайшие 30 минут нужно будет выполнить привычку: " +
                                  $"{user.HabitName ?? "не указана"} ({user.Start} - {user.End})\n";
                        user_message.Add(new Tuple<string, string>(user.UserName, message));
                        await _botClient.SendMessage(
                            chatId: subscriber.ChatId,
                            text: message
                        );
                    }
                }
                _messageRepo.TryNotify(user_message);

                Console.WriteLine($"{DateTime.Now}: Сообщение отправлено {cnt} подписчикам");
                await Task.Delay(TimeSpan.FromMinutes(timeout), _cts.Token);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при рассылке: {ex.Message}");
                await Task.Delay(TimeSpan.FromMinutes(timeout_err), _cts.Token);
            }
        }
    }

    private async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
    {
        try
        {
            if (update.Message is not { } message)
                return;

            var chatId = message.Chat.Id;
            var text = message.Text?.Trim() ?? string.Empty;

            if (text == "/start")
            {
                await HandleStartCommand(botClient, message);
            }
            else if (text == "/stop")
            {
                await HandleStopCommand(botClient, message);
            }
            else if (text != null && _registrationStates.TryGetValue(chatId, out var state))
            {
                if (state == RegistrationState.AwaitingLogin)
                {
                    var u = _userRepo.TryGet(text);
                    if (u == null)
                        await botClient.SendMessage(chatId, "К сожалению такого логина в системе не найдено, попробуйте еще раз.\n\n" + WelcomeMessage);
                    else
                    {
                        _tempLogins[chatId] = text;
                        _registrationStates[chatId] = RegistrationState.AwaitingPassword;
                        await botClient.SendMessage(chatId, AskPasswordMessage);
                    }
                }
                else if (state == RegistrationState.AwaitingPassword)
                {
                    var u = _userRepo.TryGet(_tempLogins[chatId]);
                    if (u == null)
                        await botClient.SendMessage(chatId, "Критическая ошибка, учетная запись не найдена.\n\n" + WelcomeMessage);
                    else if (u != null && u.PasswordHash != text)
                        await botClient.SendMessage(chatId, "Неправильный пароль, попробуйте еще раз.\n\n" + AskPasswordMessage);
                    else
                    {
                        var subscriber = new Subscriber
                        {
                            ChatId = chatId,
                            TaskTrackerLogin = _tempLogins[chatId],
                            Password = text,
                            Username = message.From.Username ?? message.From.FirstName,
                            SubscriptionDate = DateTime.Now
                        };
                        _dbContext.Subscribers.Add(subscriber);
                        await _dbContext.SaveChangesAsync();

                        _registrationStates.Remove(chatId);
                        _tempLogins.Remove(chatId);

                        Console.WriteLine($"Пользователь подписался: {subscriber.Username}, Логин: {subscriber.TaskTrackerLogin}");

                        await botClient.SendMessage(chatId, RegistrationCompleteMessage);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка обработки сообщения: {ex.Message}");
        }
    }

    private async Task HandleStartCommand(ITelegramBotClient botClient, Message message)
    {
        var chatId = message.Chat.Id;

        if (await _dbContext.Subscribers.AnyAsync(s => s.ChatId == chatId))
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: "Вы уже подписаны на рассылку"
            );
            return;
        }

        _registrationStates[chatId] = RegistrationState.AwaitingLogin;
        await botClient.SendMessage(chatId, WelcomeMessage);
    }

    private async Task HandleStopCommand(ITelegramBotClient botClient, Message message)
    {
        var chatId = message.Chat.Id;
        var subscriber = await _dbContext.Subscribers.FindAsync(chatId);

        if (subscriber != null)
        {
            _dbContext.Subscribers.Remove(subscriber);
            await _dbContext.SaveChangesAsync();

            await botClient.SendMessage(
                chatId: chatId,
                text: GoodbyeMessage
            );

            Console.WriteLine($"Пользователь отписался: {subscriber.Username}, Логин: {subscriber.TaskTrackerLogin}");
        }
        else
        {
            await botClient.SendMessage(
                chatId: chatId,
                text: "Вы не были подписаны"
            );
        }
    }

    private Task HandleErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
    {
        Console.WriteLine($"Ошибка: {exception.Message}");
        return Task.CompletedTask;
    }

    public async Task StopAsync()
    {
        _cts?.Cancel();
        Console.WriteLine("Бот остановлен. Список подписчиков:");
        var subscribers = await _dbContext.Subscribers.ToListAsync();
        foreach (var subscriber in subscribers)
        {
            Console.WriteLine($"- {subscriber.Username}: {subscriber.TaskTrackerLogin}/{subscriber.Password}");
        }
    }
}

class Program
{
    static async Task Main(string[] args)
    {
        var serviceProvider = new ServiceCollection()
            .AddSingleton<IMessageRepo, PostgresMessageRepo>()
            .AddSingleton<IUserRepo, PostgresUserRepo>()
            .AddDbContext<PostgresDBContext>(options =>
                options.UseNpgsql("Host=localhost;Port=5432;Database=habits_db;Username=postgres;Password=postgres"))
            .AddDbContext<SubscriberDbContext>(options =>
                options.UseSqlite("Data Source=subscribers.db"))
            .BuildServiceProvider();

        using (var scope = serviceProvider.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<SubscriberDbContext>();
            await db.Database.EnsureCreatedAsync();
        }

        var bot = new SubscriptionBot(
            "7665679478:AAHtpesgjfWihplWtkBB7Iuwot-6gCElWVY",
            serviceProvider.GetRequiredService<IMessageRepo>(),
            serviceProvider.GetRequiredService<IUserRepo>(),
            serviceProvider.GetRequiredService<SubscriberDbContext>());

        Console.CancelKeyPress += async (sender, e) =>
        {
            await bot.StopAsync();
            Environment.Exit(0);
        };

        await bot.StartAsync();
    }
}